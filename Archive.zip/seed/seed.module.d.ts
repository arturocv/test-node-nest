export declare class SeedModule {
}
