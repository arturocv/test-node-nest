import { Brand } from "src/brands/entities/brand.entity";
export declare const brand_SEED: Brand[];
