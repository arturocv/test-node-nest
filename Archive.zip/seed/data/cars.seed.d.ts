import { Car } from "src/cars/interfaces/car.interdace";
export declare const Cars_SEED: Car[];
