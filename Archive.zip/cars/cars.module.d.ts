export declare class CarsModule {
}
