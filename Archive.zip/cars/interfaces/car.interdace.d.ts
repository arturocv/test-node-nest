export interface Car {
    id: string;
    model: string;
    brand: string;
}
