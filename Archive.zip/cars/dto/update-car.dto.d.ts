export declare class UpdateCarDto {
    readonly id?: string;
    readonly brand?: string;
    readonly model?: string;
}
