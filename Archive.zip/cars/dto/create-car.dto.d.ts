export declare class CreateCarDto {
    readonly brand: string;
    readonly model: string;
}
