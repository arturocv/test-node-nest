export declare class UpdateBrandDto {
    name: string;
}
