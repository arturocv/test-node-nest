export declare class CreateBrandDto {
    name: string;
}
