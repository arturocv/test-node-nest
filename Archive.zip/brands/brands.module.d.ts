export declare class BrandsModule {
}
