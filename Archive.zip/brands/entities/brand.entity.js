"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Brand = void 0;
class Brand {
    id;
    name;
    createAt;
    updateAt;
}
exports.Brand = Brand;
//# sourceMappingURL=brand.entity.js.map