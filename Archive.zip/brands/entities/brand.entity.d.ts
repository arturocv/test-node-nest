export declare class Brand {
    id: string;
    name: string;
    createAt: number;
    updateAt?: number;
}
